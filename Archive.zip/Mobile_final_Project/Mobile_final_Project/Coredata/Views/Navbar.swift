//
//  Navbar.swift
//  Mobile_final_Project
//
//  Created by Lalani on 5/13/23.
//

import SwiftUI

struct Navbar: View {
    var body: some View {
            HStack {
                Image("Logo")
            }
    }
}


struct Navbar_Previews: PreviewProvider {
    static var previews: some View {
        Navbar()
    }
}
